﻿using DDD.Domain;
using DDD.Infra.MemoryDb.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDD.Infra.MemoryDb.Repositories
{
    public class DisciplinaRepository : IDisciplinaRepository
    {
        private readonly ApiContext _context;
        public DisciplinaRepository(ApiContext context) 
        {
            _context = context;
        }

        public void DeleteDisciplina(Disciplina disciplina)
        {
            try
            {
                _context.Set<Disciplina>().Remove(disciplina);
                _context.SaveChanges();
            }
            catch (Exception e)
            {

                throw;
            }
        } 

        public Disciplina GetDisciplina(int DisciplinaId)
        {
            return _context.Disciplinas.Find(DisciplinaId);
        }

        public List<Disciplina>GetDisciplinas() 
        {
            var list = _context.Disciplinas.Include(x => x.DisciplinaId).ToList();
            return list;
        }
        public void InsertDisciplina(Disciplina disciplina)
        {
            try
            {
                _context.Disciplinas.Add(disciplina);
                _context.SaveChanges();

            }
            catch (Exception)
            {

                throw;
            }
        }

        public void UpdateDisciplina(Disciplina disciplina)
        {
            try
            {
                _context.Entry(disciplina).State = EntityState.Modified;
                _context.SaveChanges(); 
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
